library(xlsx)
df<- read.xlsx("/home/shivangi/Downloads/BIGDATA MARKSSHEET.xlsx",sheetIndex=1, header=TRUE)
df
library(plotly)

#.............OVERALL COMPARISON.....................
plot_ly(df, x = ~df$COURSE, y = ~df$ANUSHA, type = 'bar', name = 'Anusha', marker = list(color = 'rgb(0,255,255)')) %>%
  add_trace(y = ~df$DEEPIKA, name = 'Deepika', marker = list(color = 'rgb((0,128,0)')) %>%
  add_trace(y = ~df$RAVALI, name = 'Ravali', marker = list(color = 'rgb(255,20,147)')) %>%
  add_trace(y = ~df$AAYUSHI, name = 'Aayushi', marker = list(color = 'rgb(0,128,128)')) %>%
  add_trace(y = ~df$CHETHAN, name = 'chetan', marker = list(color = 'rgb(255,69,0)')) %>%
  add_trace(y = ~df$SHIVANGI, name = 'shivangi', marker = list(color = 'rgb(240,128,128)')) %>%
  layout(xaxis = list(title = "overall comparision of marks", tickangle = -45),
         yaxis = list(title = ""),
         margin = list(b = 100),
         barmode = 'group')


#..................For Devops Marks........................

df<- read.xlsx("/home/shivangi/MARKSCOMPARISON.xlsx",sheetIndex=1, header=TRUE)
df

plot_ly(df, x = ~df$NAMES, y = ~df$DEVOPS, type = 'bar', text = text,
        marker = list(color = 'rgb(0,139,139)',
                      line = list(color = 'rgb(8,48,107)',
                                  width = 1.5))) %>%
  layout(title = "DEVOPS MARKS COMPARISON",
         xaxis = list(title = ""),
         yaxis = list(title = ""))

..........................................................................


#............DSA PIE CHART..........................................
plot_ly(df, labels = ~df$NAMES, values = ~df$DSA, type = 'pie') %>%
  layout(title = 'DSA MARKS COMPARISON',
         xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
         yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
................................................................................


#...............LSDS MARKS COMPARISON...........................
plot_ly(df, x = ~df$NAMES, y = ~df$LSDS, type = 'bar', text = text,
        marker = list(color = 'rgb(50,205,50)',
                      line = list(color = 'rgb(0,100,0)',
                                  width = 1.5))) %>%
  layout(title = "LSDS MARKS COMPARISON",
         xaxis = list(title = ""),
         yaxis = list(title = ""))
................................................................

#...............PSI MARKS COMPARISON.....................
plot_ly(df, x = ~df$NAMES, y = ~df$PSI, type = 'bar', text = text,
        marker = list(color = 'rgb(119,136,153)',
                      line = list(color = 'rgb((0,255,255)',
                                  width = 1.5))) %>%
  layout(title = "PSI MARKS COMPARISON",
         xaxis = list(title = ""),
         yaxis = list(title = ""))
..............................................................

